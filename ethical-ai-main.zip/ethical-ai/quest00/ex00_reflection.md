# 1. Write short, honest answers to these questions:

## How have you used AI for coding so far?

- I have used AI for checking and validating code and logic 
- sometimes i generate codes when I'm stuck especially when
 dealing with a new concept i have no idea on
- reviewing codes
- modify and expand code
- breakdown codes for deep and clearer understanding.

---

## Do you usually try problems yourself first?

I try solving problems myself if I have a basic knowledge of that concept or task, 
but after sometime of trying i go to AI for help.

---

## Can you explain code you've submitted without AI's help?

Yes I can explain code's I attempt and solve myself without the help of AI.

---

## What would happen if AI was unavailable during an exam or job test?

If AI is unavailable during an exam or job test I would not panic, but rather I will attempt the exam or job test myself because coming for an exam or job test I come prepared not with the intention of using AI

---

# 2. Identify your current pattern:
> Learner B: uses AI as a learning amplifier.

---

# 3. Write a short paragraph describing where you are today and what type of learner you want to become.

I'm a curious person open and will to learn and understand the what, why and how thing works so I use AI as a teacher, a mentor and a guide to support my learning making it more easy and efficient for me to grab concepts. I want to become not just a fast learner but a smart learner gaining mastery of anything or concept i want learn with the best approach of using AI for more effective and proficient learning.
